import React from 'react'
import RecentProgress from '../Progress/RecentProgress'
import './ProgressLadder.css'

/**
 * ProgressLadder component - Shows the RecentProgress component in a ladder format
 * This is a wrapper around RecentProgress for the Progress tab
 */
const ProgressLadder = ({ studentId, developmentPlan, playerLevel }) => {
  if (!studentId) return null

  return (
    <div className="progress-ladder">
      <RecentProgress 
        studentId={studentId}
        developmentPlan={developmentPlan}
        playerLevel={playerLevel || 'beginner'}
      />
    </div>
  )
}

export default ProgressLadder


