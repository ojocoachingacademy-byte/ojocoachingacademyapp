import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../../supabaseClient'
import { trackEvent, EVENTS } from '../../../utils/analytics'
import './ProfileTab.css'

const ProfileTab = ({ studentData, onBookLesson }) => {
  const navigate = useNavigate()
  const [accountStats, setAccountStats] = useState({
    totalLessons: 0,
    completedPractice: 0,
    joinedDate: null
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (studentData?.id) {
      fetchAccountStats()
    }
  }, [studentData])

  const fetchAccountStats = async () => {
    if (!studentData?.id) return

    try {
      // Get lesson stats
      const { data: lessons, count } = await supabase
        .from('lessons')
        .select('*', { count: 'exact' })
        .eq('student_id', studentData.id)
        .eq('status', 'completed')

      const completedPractice = lessons?.filter(
        l => l.practice_plan_completed
      ).length || 0

      setAccountStats({
        totalLessons: count || 0,
        completedPractice,
        joinedDate: studentData.created_at
      })

    } catch (error) {
      console.error('Error fetching account stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await trackEvent(EVENTS.LOGOUT)
      await supabase.auth.signOut()
      navigate('/login')
    } catch (error) {
      console.error('Error logging out:', error)
    }
  }

  const handleBookLessons = () => {
    if (onBookLesson) {
      onBookLesson()
    } else {
      // Fallback if callback not provided
      navigate('/booking')
    }
  }

  const handleContactCoach = () => {
    window.location.href = 'mailto:tobi@ojocoachingacademy.com'
  }

  if (loading) {
    return (
      <div className="profile-tab-loading">
        <div className="spinner"></div>
        <p>Loading profile...</p>
      </div>
    )
  }

  // Use lesson_credits (the actual field name) instead of lessons_remaining
  const credits = studentData?.lesson_credits || 0
  const creditsLow = credits <= 2 && credits > 0
  const creditsEmpty = credits === 0

  return (
    <div className="profile-tab">
      {/* Header */}
      <div className="profile-header">
        <div className="profile-avatar">
          {studentData?.profiles?.full_name?.charAt(0).toUpperCase() || '👤'}
        </div>
        <div className="profile-header-info">
          <h1>{studentData?.profiles?.full_name || 'Student'}</h1>
          <p className="profile-email">{studentData?.profiles?.email}</p>
        </div>
      </div>

      {/* Credits Card - Most Important */}
      <div className={`credits-card ${creditsLow ? 'low' : ''} ${creditsEmpty ? 'empty' : ''}`}>
        <div className="credits-content">
          <div className="credits-icon">🎾</div>
          <div className="credits-info">
            <span className="credits-label">Lesson Credits</span>
            <span className="credits-value">{credits}</span>
            {creditsLow && !creditsEmpty && (
              <span className="credits-warning">Running low!</span>
            )}
            {creditsEmpty && (
              <span className="credits-warning empty">No credits remaining</span>
            )}
          </div>
        </div>
        <button 
          className={`btn-credits ${creditsEmpty ? 'btn-primary' : 'btn-secondary'}`}
          onClick={handleBookLessons}
        >
          {creditsEmpty ? 'Buy Package' : 'Book More Lessons'}
        </button>
      </div>

      {/* Account Stats */}
      <div className="account-stats">
        <h3>Your Stats</h3>
        <div className="stats-grid">
          <div className="stat-item">
            <span className="stat-icon">🎾</span>
            <div className="stat-content">
              <span className="stat-value">{accountStats.totalLessons}</span>
              <span className="stat-label">Total Lessons</span>
            </div>
          </div>

          <div className="stat-item">
            <span className="stat-icon">✅</span>
            <div className="stat-content">
              <span className="stat-value">{accountStats.completedPractice}</span>
              <span className="stat-label">Practice Completed</span>
            </div>
          </div>

          <div className="stat-item">
            <span className="stat-icon">📅</span>
            <div className="stat-content">
              <span className="stat-value">
                {accountStats.joinedDate 
                  ? new Date(accountStats.joinedDate).toLocaleDateString('en-US', { 
                      month: 'short', 
                      year: 'numeric' 
                    })
                  : 'N/A'
                }
              </span>
              <span className="stat-label">Member Since</span>
            </div>
          </div>
        </div>
      </div>

      {/* Personal Information */}
      <div className="profile-section">
        <h3>Personal Information</h3>
        <div className="info-list">
          <div className="info-item">
            <span className="info-label">Name</span>
            <span className="info-value">{studentData?.profiles?.full_name || 'Not set'}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Email</span>
            <span className="info-value">{studentData?.profiles?.email || 'Not set'}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Phone</span>
            <span className="info-value">{studentData?.profiles?.phone || 'Not set'}</span>
          </div>
          {studentData?.player_level && (
            <div className="info-item">
              <span className="info-label">Player Level</span>
              <span className="info-value">{studentData.player_level.charAt(0).toUpperCase() + studentData.player_level.slice(1)}</span>
            </div>
          )}
        </div>
      </div>

      {/* Goals - Parse from development plan if exists */}
      {(() => {
        let goalText = null
        if (studentData?.development_plan) {
          try {
            const plan = typeof studentData.development_plan === 'string' 
              ? JSON.parse(studentData.development_plan) 
              : studentData.development_plan
            
            if (plan?.section1?.bigGoal) {
              const { GOAL_OPTIONS } = require('../../DevelopmentPlan/MilestonesConstants')
              const goal = GOAL_OPTIONS.find(g => g.value === plan.section1.bigGoal)
              goalText = goal ? goal.label : plan.section1.customGoal || plan.section1.bigGoal
            } else if (plan?.goals?.targetLevel) {
              goalText = plan.goals.targetLevel
            }
          } catch (e) {
            // Ignore parse errors
          }
        }
        
        if (goalText) {
          return (
            <div className="profile-section">
              <h3>Your Goals</h3>
              <div className="goals-display">
                <p>"{goalText}"</p>
              </div>
            </div>
          )
        }
        return null
      })()}

      {/* Quick Actions */}
      <div className="profile-section">
        <h3>Quick Actions</h3>
        <div className="actions-list">
          <button className="action-button" onClick={handleBookLessons}>
            <span className="action-icon">📅</span>
            <span className="action-text">Book More Lessons</span>
            <span className="action-arrow">→</span>
          </button>

          <button className="action-button" onClick={handleContactCoach}>
            <span className="action-icon">💬</span>
            <span className="action-text">Contact Coach Tobi</span>
            <span className="action-arrow">→</span>
          </button>

          <button 
            className="action-button" 
            onClick={() => window.open('https://ojocoachingacademyapp.netlify.app', '_blank')}
          >
            <span className="action-icon">📱</span>
            <span className="action-text">View Full App</span>
            <span className="action-arrow">→</span>
          </button>
        </div>
      </div>

      {/* Settings */}
      <div className="profile-section">
        <h3>Settings</h3>
        <div className="settings-list">
          <div className="setting-item">
            <div className="setting-info">
              <span className="setting-label">Email Notifications</span>
              <span className="setting-description">Receive lesson reminders and updates</span>
            </div>
            <label className="toggle-switch">
              <input type="checkbox" defaultChecked />
              <span className="toggle-slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <span className="setting-label">Practice Reminders</span>
              <span className="setting-description">Get reminded about your practice plan</span>
            </div>
            <label className="toggle-switch">
              <input type="checkbox" defaultChecked />
              <span className="toggle-slider"></span>
            </label>
          </div>
        </div>
      </div>

      {/* Logout */}
      <div className="profile-section logout-section">
        <button className="btn-logout" onClick={handleLogout}>
          <span>Logout</span>
          <span className="logout-icon">🚪</span>
        </button>
      </div>

      {/* Footer Info */}
      <div className="profile-footer">
        <p className="footer-text">
          Questions? Email <a href="mailto:tobi@ojocoachingacademy.com">tobi@ojocoachingacademy.com</a>
        </p>
        <p className="footer-text">
          <a href="https://ojocoachingacademy.com/privacy-policy.html" target="_blank" rel="noopener noreferrer">
            Privacy Policy
          </a>
          {' • '}
          <a href="https://ojocoachingacademy.com/terms.html" target="_blank" rel="noopener noreferrer">
            Terms of Service
          </a>
        </p>
      </div>
    </div>
  )
}

export default ProfileTab
