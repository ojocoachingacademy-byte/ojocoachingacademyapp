import React, { useState, useEffect } from 'react'
import { supabase } from '../../../supabaseClient'
import { trackEvent, EVENTS } from '../../../utils/analytics'
import RecentWins from '../RecentWins'
import DevelopmentPlanDisplay from '../DevelopmentPlanDisplay'
import SkillRatings from '../SkillRatings'
import MilestoneTracker from '../../DevelopmentPlan/MilestoneTracker'
import { GOAL_OPTIONS } from '../../DevelopmentPlan/MilestonesConstants'
import './ProgressTab.css'

const ProgressTab = ({ studentData, onEditPlan }) => {
  const [stats, setStats] = useState({
    totalLessons: 0,
    completedPractice: 0,
    milestonesUnlocked: 0
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    trackEvent(EVENTS.VIEW_PROGRESS)
    if (studentData?.id) {
      fetchProgressStats()
    }
  }, [studentData])

  const fetchProgressStats = async () => {
    if (!studentData?.id) return

    try {
      // Get total lessons
      const { data: lessons, count: totalCount } = await supabase
        .from('lessons')
        .select('*', { count: 'exact' })
        .eq('student_id', studentData.id)
        .eq('status', 'completed')

      // Count completed practice plans
      const completedPractice = lessons?.filter(
        l => l.practice_plan_completed
      ).length || 0

      // Get milestones unlocked
      const { data: milestones } = await supabase
        .from('student_milestones')
        .select('milestone_number', { count: 'exact' })
        .eq('student_id', studentData.id)

      setStats({
        totalLessons: totalCount || 0,
        completedPractice,
        milestonesUnlocked: milestones?.length || 0
      })

    } catch (error) {
      console.error('Error fetching progress stats:', error)
    } finally {
      setLoading(false)
    }
  }

  // Parse development plan for goals
  const getGoalText = () => {
    if (!studentData?.development_plan) return null
    
    try {
      const plan = typeof studentData.development_plan === 'string' 
        ? JSON.parse(studentData.development_plan) 
        : studentData.development_plan
      
      if (plan?.section1?.bigGoal) {
        const goal = GOAL_OPTIONS.find(g => g.value === plan.section1.bigGoal)
        return goal ? goal.label : plan.section1.customGoal || plan.section1.bigGoal
      }
      
      if (plan?.goals?.targetLevel) {
        return plan.goals.targetLevel
      }
      
      return null
    } catch (e) {
      return null
    }
  }

  if (loading) {
    return (
      <div className="progress-tab-loading">
        <div className="spinner"></div>
        <p>Loading your progress...</p>
      </div>
    )
  }

  const goalText = getGoalText()

  return (
    <div className="progress-tab">
      {/* Header */}
      <div className="progress-header">
        <h1>Your Tennis Journey 🏆</h1>
        <p className="progress-subtitle">Track your development and celebrate your wins</p>
      </div>

      {/* Overview Stats */}
      <div className="progress-overview">
        <div className="overview-card">
          <div className="overview-icon">🎾</div>
          <div className="overview-content">
            <span className="overview-value">{stats.totalLessons}</span>
            <span className="overview-label">Lessons Completed</span>
          </div>
        </div>

        <div className="overview-card">
          <div className="overview-icon">✅</div>
          <div className="overview-content">
            <span className="overview-value">{stats.completedPractice}</span>
            <span className="overview-label">Practice Completed</span>
          </div>
        </div>

        <div className="overview-card">
          <div className="overview-icon">🏆</div>
          <div className="overview-content">
            <span className="overview-value">{stats.milestonesUnlocked}</span>
            <span className="overview-label">Milestones Unlocked</span>
          </div>
        </div>
      </div>

      {/* Recent Wins */}
      {studentData?.development_plan && (
        <section className="progress-section">
          <div className="section-header">
            <div>
              <h2>🏆 Recent Wins</h2>
              <p className="section-description">Celebrate your accomplishments</p>
            </div>
          </div>
          <RecentWins 
            studentId={studentData.id} 
            developmentPlan={studentData.development_plan}
            playerLevel={studentData.player_level || 'beginner'}
            showAll={true} 
          />
        </section>
      )}

      {/* Development Plan */}
      <section className="progress-section">
        <div className="section-header">
          <div>
            <h2>📋 Your Development Plan</h2>
            <p className="section-description">Your personalized roadmap to success</p>
          </div>
        </div>
        <DevelopmentPlanDisplay 
          studentData={studentData}
          onEdit={onEditPlan}
        />
      </section>

      {/* Skill Ratings */}
      {studentData?.development_plan && (
        <section className="progress-section">
          <div className="section-header">
            <div>
              <h2>📈 Skill Development</h2>
              <p className="section-description">See how you're improving across all areas</p>
            </div>
          </div>
          <SkillRatings 
            studentId={studentData.id}
            studentData={studentData}
          />
        </section>
      )}

      {/* Milestones Tracker */}
      {studentData?.id && (
        <section className="progress-section">
          <div className="section-header">
            <div>
              <h2>🎯 Milestones</h2>
              <p className="section-description">Your tennis achievements</p>
            </div>
            <button 
              className="btn-text"
              onClick={() => trackEvent(EVENTS.VIEW_PROGRESS_LADDER)}
            >
              View Details →
            </button>
          </div>
          <MilestoneTracker 
            studentId={studentData.id}
            isCoach={false}
            playerLevel={studentData.player_level || 'beginner'}
          />
        </section>
      )}

      {/* Goals Section */}
      <section className="progress-section goals-section">
        <div className="section-header">
          <h2>🎯 Your Goals</h2>
        </div>
        <div className="goals-card">
          {goalText ? (
            <>
              <p className="goal-text">"{goalText}"</p>
              <div className="goal-status">
                <span className="status-icon">🔥</span>
                <span className="status-text">You're on track! Keep going.</span>
              </div>
            </>
          ) : (
            <div className="no-goals">
              <p>Set your tennis goals to stay motivated</p>
              {onEditPlan && (
                <button className="btn-secondary" onClick={onEditPlan}>
                  Set Goals →
                </button>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

export default ProgressTab
