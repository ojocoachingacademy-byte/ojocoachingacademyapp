import React from 'react'
import { trackEvent, EVENTS } from '../../utils/analytics'
import './StudentTabs.css'

const StudentTabs = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'progress', label: 'Progress', icon: '📊' },
    { id: 'lessons', label: 'Lessons', icon: '📅' },
    { id: 'profile', label: 'Profile', icon: '👤' }
  ]

  const handleTabChange = (tabId) => {
    setActiveTab(tabId)
    trackEvent(EVENTS.TAB_CHANGE, { from: activeTab, to: tabId })
  }

  return (
    <nav className="student-tabs">
      {tabs.map(tab => (
        <button
          key={tab.id}
          className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
          onClick={() => handleTabChange(tab.id)}
          aria-label={tab.label}
        >
          <span className="tab-icon">{tab.icon}</span>
          <span className="tab-label">{tab.label}</span>
        </button>
      ))}
    </nav>
  )
}

export default StudentTabs


