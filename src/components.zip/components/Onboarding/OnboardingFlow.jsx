import React, { useState, useEffect } from 'react'
import { supabase } from '../../supabaseClient'
import { trackEvent, EVENTS } from '../../utils/analytics'
import WelcomeScreen from './screens/WelcomeScreen'
import ExperienceScreen from './screens/ExperienceScreen'
import GoalsScreen from './screens/GoalsScreen'
import FirstLessonScreen from './screens/FirstLessonScreen'
import CompleteScreen from './screens/CompleteScreen'
import './OnboardingFlow.css'

const OnboardingFlow = ({ studentData, onComplete }) => {
  const [currentStep, setCurrentStep] = useState(1)
  const [onboardingData, setOnboardingData] = useState({
    experienceLevel: '',
    goals: '',
    upcomingLesson: null
  })

  useEffect(() => {
    trackEvent(EVENTS.ONBOARDING_START)
    fetchUpcomingLesson()
  }, [])

  const fetchUpcomingLesson = async () => {
    if (!studentData?.id) return
    
    try {
      const { data } = await supabase
        .from('lessons')
        .select('*')
        .eq('student_id', studentData.id)
        .eq('status', 'scheduled')
        .gte('lesson_date', new Date().toISOString())
        .order('lesson_date', { ascending: true })
        .limit(1)
        .maybeSingle()

      setOnboardingData(prev => ({ ...prev, upcomingLesson: data }))
    } catch (error) {
      console.error('Error fetching upcoming lesson:', error)
    }
  }

  const updateOnboardingData = (key, value) => {
    setOnboardingData(prev => ({ ...prev, [key]: value }))
  }

  const nextStep = () => {
    setCurrentStep(prev => prev + 1)
  }

  const prevStep = () => {
    setCurrentStep(prev => Math.max(1, prev - 1))
  }

  const completeOnboarding = async () => {
    try {
      // Save onboarding data to student profile
      const updateData = {
        onboarding_completed: true,
        onboarding_completed_at: new Date().toISOString()
      }

      // Add experience level if provided
      if (onboardingData.experienceLevel) {
        // Map experience level to skill_level or player_level
        if (onboardingData.experienceLevel === 'complete_beginner' || onboardingData.experienceLevel === 'beginner') {
          updateData.player_level = 'beginner'
        } else if (onboardingData.experienceLevel === 'advanced') {
          updateData.player_level = 'advanced'
        }
      }

      // Add goals if provided
      if (onboardingData.goals) {
        updateData.goals = onboardingData.goals
      }

      const { error } = await supabase
        .from('students')
        .update(updateData)
        .eq('id', studentData.id)

      if (error) throw error

      trackEvent(EVENTS.ONBOARDING_COMPLETE, {
        experience_level: onboardingData.experienceLevel,
        has_goals: !!onboardingData.goals
      })

      // Call parent callback
      onComplete()

    } catch (error) {
      console.error('Error completing onboarding:', error)
      alert('Failed to save your information. Please try again.')
    }
  }

  const totalSteps = 5
  const progress = (currentStep / totalSteps) * 100

  return (
    <div className="onboarding-overlay">
      <div className="onboarding-container">
        {/* Progress Bar */}
        <div className="onboarding-progress-bar">
          <div 
            className="onboarding-progress-fill" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>

        {/* Progress Indicator */}
        <div className="onboarding-step-indicator">
          Step {currentStep} of {totalSteps}
        </div>

        {/* Screen Content */}
        <div className="onboarding-screen">
          {currentStep === 1 && (
            <WelcomeScreen 
              studentName={studentData?.profiles?.full_name}
              onNext={nextStep}
            />
          )}

          {currentStep === 2 && (
            <ExperienceScreen
              value={onboardingData.experienceLevel}
              onChange={(value) => updateOnboardingData('experienceLevel', value)}
              onNext={nextStep}
              onBack={prevStep}
            />
          )}

          {currentStep === 3 && (
            <GoalsScreen
              value={onboardingData.goals}
              onChange={(value) => updateOnboardingData('goals', value)}
              onNext={nextStep}
              onBack={prevStep}
            />
          )}

          {currentStep === 4 && (
            <FirstLessonScreen
              lesson={onboardingData.upcomingLesson}
              onNext={nextStep}
              onBack={prevStep}
            />
          )}

          {currentStep === 5 && (
            <CompleteScreen
              onComplete={completeOnboarding}
            />
          )}
        </div>
      </div>
    </div>
  )
}

export default OnboardingFlow


