import React from 'react'
import './OnboardingScreens.css'

const WelcomeScreen = ({ studentName, onNext }) => {
  const firstName = studentName?.split(' ')[0] || 'there'

  return (
    <div className="onboarding-screen-content welcome-screen">
      <div className="welcome-icon">🎾</div>
      
      <h1 className="welcome-title">
        Welcome to Ojo Academy, {firstName}!
      </h1>
      
      <p className="welcome-text">
        Let's set up your profile before your first lesson. This takes just 2 minutes.
      </p>

      <div className="welcome-features">
        <div className="welcome-feature">
          <span className="feature-icon">📊</span>
          <span className="feature-text">Track your progress</span>
        </div>
        <div className="welcome-feature">
          <span className="feature-icon">🎯</span>
          <span className="feature-text">Set and achieve goals</span>
        </div>
        <div className="welcome-feature">
          <span className="feature-icon">🏆</span>
          <span className="feature-text">Unlock milestones</span>
        </div>
      </div>

      <button className="btn-primary btn-large" onClick={onNext}>
        Get Started →
      </button>
    </div>
  )
}

export default WelcomeScreen


