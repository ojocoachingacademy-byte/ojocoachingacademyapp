import React from 'react'
import './OnboardingScreens.css'

const FirstLessonScreen = ({ lesson, onNext, onBack }) => {
  if (!lesson) {
    return (
      <div className="onboarding-screen-content first-lesson-screen">
        <h2 className="screen-title">No lesson scheduled yet</h2>
        <p className="screen-subtitle">Book your first lesson to get started!</p>
        
        <div className="screen-buttons">
          <button className="btn-secondary" onClick={onBack}>
            ← Back
          </button>
          <button className="btn-primary" onClick={onNext}>
            Skip →
          </button>
        </div>
      </div>
    )
  }

  const lessonDate = new Date(lesson.lesson_date)
  const formatDate = (date) => ({
    day: date.toLocaleDateString('en-US', { weekday: 'long' }),
    date: date.toLocaleDateString('en-US', { month: 'long', day: 'numeric' }),
    time: date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
  })

  const { day, date, time } = formatDate(lessonDate)

  return (
    <div className="onboarding-screen-content first-lesson-screen">
      <div className="lesson-icon">📅</div>
      
      <h2 className="screen-title">Your First Lesson</h2>
      
      <div className="lesson-details-card">
        <div className="lesson-detail">
          <span className="detail-label">When</span>
          <span className="detail-value">{day}</span>
          <span className="detail-value large">{date}</span>
          <span className="detail-value">{time}</span>
        </div>
        
        <div className="lesson-divider"></div>
        
        <div className="lesson-detail">
          <span className="detail-label">Where</span>
          <span className="detail-value">{lesson.location || 'Colina Del Sol Park'}</span>
          <span className="detail-note">📍 Exact court details sent 24hrs before</span>
        </div>
      </div>

      <div className="what-to-bring">
        <h3>What to Bring:</h3>
        <div className="bring-list">
          <div className="bring-item">
            <span className="bring-icon">🎾</span>
            <span>Tennis racquet</span>
          </div>
          <div className="bring-item">
            <span className="bring-icon">💧</span>
            <span>Water bottle</span>
          </div>
          <div className="bring-item">
            <span className="bring-icon">👟</span>
            <span>Athletic shoes</span>
          </div>
        </div>
      </div>

      <div className="screen-buttons">
        <button className="btn-secondary" onClick={onBack}>
          ← Back
        </button>
        <button className="btn-primary" onClick={onNext}>
          I'm Ready! →
        </button>
      </div>
    </div>
  )
}

export default FirstLessonScreen


